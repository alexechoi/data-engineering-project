import json
import pymongo
from pymongo import MongoClient
import psycopg2
from datetime import datetime

# Establish connection with MongoDB
client = MongoClient('mongodb://54.174.84.60:27017/')
mongodb = client.group_db

# Connect to PostgreSQL database
conn = psycopg2.connect("host=group-db-postgres.chgpebgxxbjx.us-east-1.rds.amazonaws.com dbname=postgres user=postgres password=Zeynep1234")
cur = conn.cursor()

hotels = list(mongodb.hotels.find())
train_stations = list(mongodb.coordinates_train.find())
tweets = list(mongodb.tweets.find())
uber_data = list(mongodb.uber.find())
weather_data = list(mongodb.weather.find())
routes_data = json.loads(routes_json)  # Assuming routes_json is the JSON string you provided

# Transform data

def transform_hotel_data(hotels):
    hotel_info = []
    hotel_location = []

    for hotel in hotels:
        # Assuming 'id' field in the hotels collection is a unique integer, use it as 'hotel_id'
        hotel_id = hotel.get('_id')

        # Extract 'name' and 'location' fields from the hotel document
        name = hotel.get('name')
        location = hotel.get('location')

        hotel_info.append({"id": hotel_id, "name": name, "neighbourhood": location})
        
        # Assuming you have latitude and longitude fields in the 'hotels' collection
        lat = hotel.get('latitude')
        long = hotel.get('longitude')

        hotel_location.append({"id": hotel_id, "hotel_id": hotel_id, "lat": lat, "long": long})

    return hotel_info, hotel_location

def transform_train_station_data(train_stations):
    train_station_data = []

    for station in train_stations:
        # Assuming 'id' field in the train_stations collection is a unique integer
        station_id = station.get('_id')

        # Extract 'name', 'latitude', and 'longitude' fields from the station document
        name = station.get('name')
        lat = station.get('latitude')
        long = station.get('longitude')

        train_station_data.append({"id": station_id, "name": name, "lat": lat, "long": long})

    return train_station_data

def transform_tweet_data(tweets):
    tweet_data = []
    tweet_metadata = []

    for tweet in tweets:
        # Extracting necessary fields from the tweet document
        tweet_id = tweet.get('id')
        text = tweet.get('text')
        edit_history_tweet_ids = tweet.get('edit_history_tweet_ids')

        tweet_data.append({"id": tweet_id, "text": text})

        # Assuming newest_id and oldest_id are fields in the tweets collection
        newest_id = tweet.get('newest_id')
        oldest_id = tweet.get('oldest_id')
        result_count = len(edit_history_tweet_ids)

        tweet_metadata.append({"id": tweet_id, "newest_id": newest_id, "oldest_id": oldest_id, "result_count": result_count, "tweet_id": tweet_id})

    return tweet_data, tweet_metadata

def transform_uber_data(uber_data, routes_data):
    transformed_data = []

    for uber_item in uber_data:
        origin_latitude = uber_item['origin_latitude']
        origin_longitude = uber_item['origin_longitude']
        destination_latitude = uber_item['destination_latitude']
        destination_longitude = uber_item['destination_longitude']

        # Find the route_id for the given start and end coordinates
        route_id = None
        for route in routes_data:
            if (route['start_coordinate']['latitude'] == origin_latitude
                    and route['start_coordinate']['longitude'] == origin_longitude
                    and route['end_coordinate']['latitude'] == destination_latitude
                    and route['end_coordinate']['longitude'] == destination_longitude):
                route_id = route['id']
                break

        if route_id is not None:
            transformed_data.append({
                'id': int(uber_item['_id']),
                'route_id': route_id,
                'time_stamp': uber_item['timestamp']
            })

    return transformed_data


def transform_weather_data(weather_data):
    weather_location = []
    weather_main = []
    weather_conditions = []

    for weather in weather_data:
        location_id = None  # Replace with logic to map latitude and longitude to train_stations id
        main_id = weather.get('weather_id')
        condition_id = weather.get('_id')
        dt = weather.get('dt')

        weather_location.append({"id": condition_id, "location_id": location_id, "main_id": main_id, "condition_id": condition_id, "dt": dt})

        main = weather.get('weather_main')
        desc = weather.get('weather_desc')

        weather_main.append({"id": main_id, "main": main, "desc": desc})

        temperature = weather.get('temperature')
        feels_like = weather.get('feels_like')
        clouds = weather.get('clouds')

        weather_conditions.append({"id": condition_id, "temperature": temperature, "feels_like": feels_like, "clouds": clouds})

    return weather_location, weather_main, weather_conditions

def transform_routes_data(routes_data):
    transformed_data = []
    location_ids = {}

    current_location_id = 1

    for route_id, coordinates in routes_data.items():
        start_lat = coordinates['start_coordinate']['latitude']
        start_long = coordinates['start_coordinate']['longitude']
        end_lat = coordinates['end_coordinate']['latitude']
        end_long = coordinates['end_coordinate']['longitude']

        start_coordinates = (start_lat, start_long)
        end_coordinates = (end_lat, end_long)

        # Generate unique IDs for start and end locations
        if start_coordinates not in location_ids:
            location_ids[start_coordinates] = current_location_id
            current_location_id += 1
        start_location_id = location_ids[start_coordinates]

        if end_coordinates not in location_ids:
            location_ids[end_coordinates] = current_location_id
            current_location_id += 1
        end_location_id = location_ids[end_coordinates]

        transformed_data.append({
            'id': int(route_id),
            'start_location_id': start_location_id,
            'end_location_id': end_location_id
        })

    return transformed_data


# Insert Data
import psycopg2

def insert_hotel_data(data):
    hotel_info, hotel_location = data

    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in hotel_info:
                cur.execute("""
                    INSERT INTO hotel_info (id, name, neighbourhood)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['name'], record['neighbourhood']))
            conn.commit()

            for record in hotel_location:
                cur.execute("""
                    INSERT INTO hotel_location (id, hotel_id, lat, long)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['hotel_id'], record['lat'], record['long']))
            conn.commit()

def insert_train_station_data(data):
    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in data:
                cur.execute("""
                    INSERT INTO train_stations (id, name, lat, long)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['name'], record['lat'], record['long']))
            conn.commit()

def insert_tweet_data(data):
    tweets, tweet_metadata = data

    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in tweets:
                cur.execute("""
                    INSERT INTO tweets (id, text, edit_history_tweet_ids)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['text'], record['edit_history_tweet_ids']))
            conn.commit()

            for record in tweet_metadata:
                cur.execute("""
                    INSERT INTO tweet_metadata (id, newest_id, oldest_id, result_count, tweet_id)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['newest_id'], record['oldest_id'], record['result_count'], record['tweet_id']))
            conn.commit()

def insert_uber_data(data):
    uber_ride, uber_price = data

    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in uber_ride:
                cur.execute("""
                    INSERT INTO uber_ride (id, route_id, time_stamp)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['route_id'], record['time_stamp']))
            conn.commit()

            for record in uber_price:
                cur.execute("""
                    INSERT INTO uber_price (id, ride_id, x, green, assist, access, pet, comfort, xl, exec, lux)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['ride_id'], record['x'], record['green'], record['assist'], record['access'], record['pet'], record['comfort'], record['xl'], record['exec'], record['lux']))
            conn.commit()

def insert_weather_data(data):
    weather_location, weather_main, weather_conditions = data

    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in weather_location:
                cur.execute("""
                    INSERT INTO weather_location (id, location_id, main_id, condition_id, dt)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['location_id'], record['main_id'], record['condition_id'], record['dt']))
            conn.commit()

            for record in weather_main:
                cur.execute("""
                    INSERT INTO weather_main (id, main, desc)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['main'], record['desc']))
            conn.commit()

            for record in weather_conditions:
                cur.execute("""
                    INSERT INTO weather_conditions (id, temperature, feels_like, clouds)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['temperature'], record['feels_like'], record['clouds']))
            conn.commit()

def insert_routes_data(data):
    routes, start_location, end_location = data

    with psycopg2.connect(postgres_connection) as conn:
        with conn.cursor() as cur:
            for record in routes:
                cur.execute("""
                    INSERT INTO routes (id, start_location_id, end_location_id)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['start_location_id'], record['end_location_id']))
            conn.commit()

            for record in start_location:
                cur.execute("""
                    INSERT INTO train_stations (id, name, lat, long)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['name'], record['lat'], record['long']))
            conn.commit()

            for record in end_location:
                cur.execute("""
                    INSERT INTO hotel_location (id, hotel_id, lat, long)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (record['id'], record['hotel_id'], record['lat'], record['long']))
            conn.commit()

# Close connections
client.close()
cur.close()
conn.close()
