import os
import json
import psycopg2
from pymongo import MongoClient
from psycopg2.extras import execute_values

def lambda_handler(event, context):
    # MongoDB configuration
    mongodb_uri = "mongodb://54.174.84.60:27017/group_db"

    # PostgreSQL configuration
    postgres_connection = "host=group-db-postgres.chgpebgxxbjx.us-east-1.rds.amazonaws.com dbname=postgres user=postgres password=Zeynep1234"

    # Connect to MongoDB
    try:
        mongo_client = MongoClient(mongodb_uri)
        mongo_db = mongo_client.group_db
    except Exception as e:
        print(f"Error connecting to MongoDB: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"message": "Error connecting to MongoDB"})}

    # Connect to PostgreSQL
    try:
        postgres_conn = psycopg2.connect(postgres_connection)
        postgres_cursor = postgres_conn.cursor()
    except Exception as e:
        print(f"Error connecting to PostgreSQL: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"message": "Error connecting to PostgreSQL"})}

    # Transform and insert MongoDB data into PostgreSQL tables
    try:
        # You can create specific functions for each transformation and insertion here
        transform_and_insert_hotel_data(mongo_db, postgres_cursor)
        transform_and_insert_weather_data(mongo_db, postgres_cursor)
        transform_and_insert_routes_data(mongo_db, postgres_cursor)
        transform_and_insert_uber_data(mongo_db, postgres_cursor)
        transform_and_insert_train_stations_data(mongo_db, postgres_cursor)
        transform_and_insert_tweets_data(mongo_db, postgres_cursor)

        postgres_conn.commit()

    except Exception as e:
        print(f"Error transforming and inserting data: {str(e)}")
        postgres_conn.rollback()

    # Close connections
    postgres_cursor.close()
    postgres_conn.close()
    mongo_client.close()

    return {"statusCode": 200, "body": json.dumps({"message": "Data successfully transferred from MongoDB to PostgreSQL"})}

def transform_and_insert_hotel_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['hotels'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: hotels")
        return

    # Transform MongoDB documents and insert them into PostgreSQL tables
    for doc in mongo_data:
        # Extract data from the document
        hotel_name = doc.get("name")
        hotel_location = doc.get("location")

        # Insert data into the hotel_info table
        if hotel_name and hotel_location:
            postgres_cursor.execute("INSERT INTO hotel_info (name, neighbourhood) VALUES (%s, %s) RETURNING id", (hotel_name, hotel_location))
            hotel_id = postgres_cursor.fetchone()[0]

            # Insert data into the hotel_location table
            # Get latitude and longitude values from MongoDB document
            latitude = doc.get("latitude")
            longitude = doc.get("longitude")
            if latitude and longitude:
                postgres_cursor.execute("INSERT INTO hotel_location (hotel_id, lat, long) VALUES (%s, %s, %s)", (hotel_id, latitude, longitude))
                print(f"Inserted hotel data for {hotel_name} with location ({latitude}, {longitude})")
            else:
                print(f"Latitude and/or longitude missing for hotel: {hotel_name}")
        else:
            print("Hotel name and/or location missing in MongoDB document")
    postgres_conn.commit()
    print("Finished inserting hotel data")


def transform_and_insert_weather_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['weather'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: weather")
        return

    # Transform MongoDB documents and insert them into PostgreSQL tables
    for doc in mongo_data:
        # Extract data from the document
        longitude = doc.get("longitude")
        latitude = doc.get("latitude")
        weather_id = doc.get("weather_id")
        weather_main = doc.get("weather_main")
        weather_desc = doc.get("weather_desc")
        temperature = doc.get("temperature")
        feels_like = doc.get("feels_like")
        clouds = doc.get("clouds")
        dt = doc.get("dt")
        location_id = doc.get("id")

        # Insert data into the weather_main and weather_conditions tables
        if weather_id and weather_main and weather_desc:
            # Insert a new record into weather_main
            postgres_cursor.execute("INSERT INTO weather_main (id, main, desc) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (weather_id, weather_main, weather_desc))
            print("Inserted data into weather_main table")

            # Insert a new record into weather_conditions
            postgres_cursor.execute("INSERT INTO weather_conditions (id, temperature, feels_like, clouds) VALUES (%s, %s, %s, %s) ON CONFLICT (id) DO NOTHING", (weather_id, temperature, feels_like, clouds))
            print("Inserted data into weather_conditions table")

        # Insert data into the weather_location table
        if location_id and weather_id and dt:
            # Insert a new record into weather_location
            postgres_cursor.execute("INSERT INTO weather_location (id, location_id, main_id, condition_id, dt) VALUES (%s, %s, %s, %s, to_timestamp(%s)) ON CONFLICT (id) DO NOTHING", (location_id, location_id, weather_id, weather_id, dt))
            print("Inserted data into weather_location table")


def transform_and_insert_routes_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['routes'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: routes")
        return

    # Transform MongoDB documents and insert them into the PostgreSQL table
    for doc in mongo_data:
        for route_id, route_info in doc.items():
            # Extract data from the document
            start_coordinate = route_info.get("start_coordinate", {})
            end_coordinate = route_info.get("end_coordinate", {})

            start_latitude = start_coordinate.get("latitude")
            start_longitude = start_coordinate.get("longitude")
            end_latitude = end_coordinate.get("latitude")
            end_longitude = end_coordinate.get("longitude")

            # Insert data into the hotel_location and train_stations tables (if not already present)
            postgres_cursor.execute("INSERT INTO hotel_location (id, lat, long) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, start_latitude, start_longitude))
            postgres_cursor.execute("INSERT INTO train_stations (id, lat, long) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, end_latitude, end_longitude))

            # Insert data into the routes table
            postgres_cursor.execute("INSERT INTO routes (id, start_location_id, end_location_id) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, route_id, route_id))


def transform_and_insert_uber_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['uber'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: uber")
        return

    # Transform MongoDB documents and insert them into PostgreSQL tables
    for doc in mongo_data:
        # Extract data from the document
        timestamp = doc.get("timestamp")
        readable_timestamp = doc.get("readable_timestamp")
        prices = doc.get("prices")

        # Insert data into the routes, uber_ride, and uber_price tables
        if timestamp and readable_timestamp and prices:
            # Insert a new route (assuming that start_location_id and end_location_id are available)
            # Replace the hardcoded values with the actual start_location_id and end_location_id values
            start_location_id = 1
            end_location_id = 2
            postgres_cursor.execute("INSERT INTO routes (start_location_id, end_location_id) VALUES (%s, %s) RETURNING id", (start_location_id, end_location_id))
            route_id = postgres_cursor.fetchone()[0]

            # Insert a new uber_ride
            postgres_cursor.execute("INSERT INTO uber_ride (route_id, time_stamp) VALUES (%s, %s) RETURNING id", (route_id, readable_timestamp))
            ride_id = postgres_cursor.fetchone()[0]

            # Insert uber_price records
            for price in prices:
                if len(price) == 2:
                    product, price_range = price
                    postgres_cursor.execute("INSERT INTO uber_price (ride_id, x, green, assist, access, pet, comfort, xl, exec, lux) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (ride_id, product, price_range, price_range, price_range, price_range, price_range, price_range, price_range, price_range))


def transform_and_insert_train_stations_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = mongo_db['train_stations'].find_one({})

    if not mongo_data:
        print("No data found in MongoDB collection: train_stations")
        return

    # Transform MongoDB document and insert train station data into PostgreSQL tables
    for station_name, coordinates in mongo_data.items():
        latitude = coordinates.get("latitude")
        longitude = coordinates.get("longitude")

        # Insert data into the train_station and train_station_location tables
        if station_name and latitude and longitude:
            # Insert a new record into the train_station table
            postgres_cursor.execute("INSERT INTO train_station (name) VALUES (%s) RETURNING id", (station_name,))
            station_id = postgres_cursor.fetchone()[0]

            # Insert a new record into the train_station_location table
            postgres_cursor.execute("INSERT INTO train_station_location (train_station_id, lat, long) VALUES (%s, %s, %s)", (station_id, latitude, longitude))


def transform_and_insert_tweets_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['tweets'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: tweets")
        return

    # Transform MongoDB documents and insert them into PostgreSQL tables
    for doc in mongo_data:
        # Extract data from the document
        tweet_id = doc.get("id")
        text = doc.get("text")

        # Insert data into the tweets table
        if tweet_id and text:
            postgres_cursor.execute("INSERT INTO tweets (id, text) VALUES (%s, %s) ON CONFLICT (id) DO NOTHING", (tweet_id, text))
            print(f"Inserted tweet with ID {tweet_id} into the PostgreSQL database")
        else:
            print(f"Skipping tweet with missing ID or text: {doc}")
