import os
import json
import psycopg2
from pymongo import MongoClient
from psycopg2.extras import execute_values

def lambda_handler(event, context):
    # MongoDB configuration
    mongodb_uri = "mongodb://54.174.84.60:27017/group_db"

    # PostgreSQL configuration
    postgres_connection = "host=group-db-postgres.chgpebgxxbjx.us-east-1.rds.amazonaws.com dbname=postgres user=postgres password=Zeynep1234"

    # Connect to MongoDB
    try:
        mongo_client = MongoClient(mongodb_uri)
        mongo_db = mongo_client.group_db
    except Exception as e:
        print(f"Error connecting to MongoDB: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"message": "Error connecting to MongoDB"})}

    # Connect to PostgreSQL
    try:
        postgres_conn = psycopg2.connect(postgres_connection)
        postgres_cursor = postgres_conn.cursor()
    except Exception as e:
        print(f"Error connecting to PostgreSQL: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"message": "Error connecting to PostgreSQL"})}

    # Transform and insert MongoDB data into PostgreSQL tables
    try:
        transform_and_insert_routes_data(mongo_db, postgres_cursor)

        postgres_conn.commit()

    except Exception as e:
        print(f"Error transforming and inserting data: {str(e)}")
        postgres_conn.rollback()

    # Close connections
    postgres_cursor.close()
    postgres_conn.close()
    mongo_client.close()

    return {"statusCode": 200, "body": json.dumps({"message": "Data successfully transferred from MongoDB to PostgreSQL"})}

def transform_and_insert_routes_data(mongo_db, postgres_cursor):
    # Fetch data from MongoDB collection
    mongo_data = list(mongo_db['routes'].find({}))

    if not mongo_data:
        print("No data found in MongoDB collection: routes")
        return

    # Transform MongoDB documents and insert them into the PostgreSQL table
    for doc in mongo_data:
        route_id = doc.get('route_id')
        if not route_id:
            print(f"No route_id found in document: {doc}")
            continue
        
        # Extract data from the document
        start_coordinate = doc.get("start_coordinate", {})
        end_coordinate = doc.get("end_coordinate", {})

        start_latitude = start_coordinate.get("latitude")
        start_longitude = start_coordinate.get("longitude")
        end_latitude = end_coordinate.get("latitude")
        end_longitude = end_coordinate.get("longitude")

        # Insert data into the hotel_location and train_stations tables (if not already present)
        postgres_cursor.execute("INSERT INTO hotel_location (id, lat, long) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, start_latitude, start_longitude))
        postgres_cursor.execute("INSERT INTO train_stations (id, lat, long) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, end_latitude, end_longitude))

        # Insert data into the routes table
        postgres_cursor.execute("INSERT INTO routes (id, start_location_id, end_location_id) VALUES (%s, %s, %s) ON CONFLICT (id) DO NOTHING", (route_id, route_id, route_id))
    
    print("Data transformation and insertion complete.")

